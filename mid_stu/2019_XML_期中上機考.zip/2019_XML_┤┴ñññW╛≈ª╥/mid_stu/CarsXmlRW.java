package mid_stu;

import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.stream.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 *
 * @author Jason
 */
public class CarsXmlRW extends DefaultHandler {

    private SAXParserFactory saxParserFactory;
    private SAXParser saxParser;
    private StringWriter stringWriter;
    private XMLOutputFactory xmlOutputFactory;
    private XMLStreamWriter xmlStreamWriter;
    private String str;
    private List<Car> carList;
    private String name;
    private int price;
    private boolean imported;

    public CarsXmlRW() {
        carList = new ArrayList<>();
    }
    
    public List<Car> read(){

        return carList;
    }
    
    public void write(List<Car> list){
        
    }


}
